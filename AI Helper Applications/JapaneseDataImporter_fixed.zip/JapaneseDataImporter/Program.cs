using System.Text.Json;
using System.Text.Json.Serialization;
using Npgsql;
using NpgsqlTypes;

internal static class Program
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNameCaseInsensitive = true
    };

    private static async Task<int> Main(string[] args)
    {
        if (args.Length is < 2 or > 3 ||
            (args.Length == 3 && args[2] != "--validate-only"))
        {
            Console.WriteLine("Usage:");
            Console.WriteLine("  dotnet run -- <kanji-folder> <vocabulary-json> [--validate-only]");
            Console.WriteLine();
            Console.WriteLine("Set VOCABULARITY_POSTGRES_CONNECTION before importing.");
            return 1;
        }

        string kanjiFolder = Path.GetFullPath(args[0]);
        string vocabularyFile = Path.GetFullPath(args[1]);
        bool validateOnly = args.Length == 3;

        try
        {
            // First load and validate EVERY file, before modifying the database.
            var kanji = await LoadKanjiAsync(kanjiFolder);
            var vocabulary = await LoadVocabularyAsync(vocabularyFile);

            Console.WriteLine($"Kanji: {kanji.Count}");
            Console.WriteLine($"Kanji meanings: {kanji.Sum(k => k.Meanings.Count)}");
            Console.WriteLine($"Kanji readings: {kanji.Sum(k => k.Readings.Count)}");
            Console.WriteLine($"Vocabulary: {vocabulary.Count}");
            Console.WriteLine($"Vocabulary meanings: {vocabulary.Sum(v => v.Data!.Meanings.Count)}");
            Console.WriteLine($"Vocabulary readings: {vocabulary.Sum(v => v.Data!.Readings.Count)}");

            if (validateOnly)
            {
                Console.WriteLine("Validation succeeded. Nothing was written to PostgreSQL.");
                return 0;
            }

            string? connectionString =
                Environment.GetEnvironmentVariable("VOCABULARITY_POSTGRES_CONNECTION");
            if (string.IsNullOrWhiteSpace(connectionString))
                throw new InvalidOperationException(
                    "Set the VOCABULARITY_POSTGRES_CONNECTION environment variable.");

            await using var connection = new NpgsqlConnection(connectionString);
            await connection.OpenAsync();
            await using var transaction = await connection.BeginTransactionAsync();

            try
            {
                // Never overwrite existing lessons or delete user data.
                await EnsureJapaneseTablesEmptyAsync(connection, transaction);

                var lessonIds = Enumerable.Range(1, 60)
                    .ToDictionary(lesson => lesson, _ => Guid.NewGuid());

                Console.WriteLine("Importing 60 Japanese lessons...");
                await ImportLessonsAsync(connection, lessonIds);

                Console.WriteLine("Importing Kanji...");
                var kanjiRows = kanji.Select(k => new KanjiRow(
                    k, Guid.NewGuid(), Guid.NewGuid())).ToList();
                await ImportKanjiAsync(connection, lessonIds, kanjiRows);
                await ImportKanjiMeaningsAsync(connection, kanjiRows);
                await ImportKanjiReadingsAsync(connection, kanjiRows);

                Console.WriteLine("Importing vocabulary...");
                var vocabularyRows = vocabulary.Select(v => new VocabularyRow(
                    v, Guid.NewGuid(), Guid.NewGuid())).ToList();
                await ImportVocabularyAsync(connection, lessonIds, vocabularyRows);
                await ImportVocabularyMeaningsAsync(connection, vocabularyRows);
                await ImportVocabularyReadingsAsync(connection, vocabularyRows);

                await VerifyCountsAsync(connection, transaction, kanjiRows, vocabularyRows);
                await transaction.CommitAsync();
                Console.WriteLine("Import completed and committed successfully.");
                return 0;
            }
            catch
            {
                await transaction.RollbackAsync();
                Console.Error.WriteLine("Import failed. All database changes were rolled back.");
                throw;
            }
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine($"ERROR: {ex.Message}");
            return 1;
        }
    }

    private static async Task<List<KanjiSubject>> LoadKanjiAsync(string folder)
    {
        if (!Directory.Exists(folder))
            throw new DirectoryNotFoundException($"Kanji folder not found: {folder}");

        var result = new List<KanjiSubject>();
        var ids = new Dictionary<int, (int Lesson, string Character)>();
        var characters = new Dictionary<string, (int Id, int Lesson)>(StringComparer.Ordinal);
        var duplicates = new List<string>();

        for (int lesson = 1; lesson <= 60; lesson++)
        {
            string path = Path.Combine(folder, $"Kanjis_Lesson{lesson}.json");
            if (!File.Exists(path))
                throw new FileNotFoundException($"Missing Kanji lesson {lesson}: {path}");

            // ReadAllTextAsync handles UTF-8 files with or without a BOM.
            string json = await File.ReadAllTextAsync(path);
            var entries = JsonSerializer.Deserialize<List<KanjiEnvelope>>(json, JsonOptions)
                ?? throw new InvalidDataException($"Invalid Kanji array: {path}");

            if (entries.Count == 0)
                throw new InvalidDataException($"Empty Kanji file: {path}");

            foreach (var entry in entries)
            {
                var k = entry.KanjiJson
                    ?? throw new InvalidDataException($"Missing KanjiJson in {path}");

                if (k.LessonNumber != lesson)
                    throw new InvalidDataException(
                        $"Kanji {k.Id} in {path} has lessonNumber={k.LessonNumber}.");
                if (k.Id <= 0 || string.IsNullOrWhiteSpace(k.Kanji))
                    throw new InvalidDataException($"Invalid Kanji ID/character in {path}.");
                // Report each conflict and its source lessons instead of stopping at the first.
                // Do not silently discard data: a duplicate across lessons needs review.
                if (ids.TryGetValue(k.Id, out var priorId))
                {
                    duplicates.Add($"Duplicate Kanji ID {k.Id}: " +
                        $"lesson {priorId.Lesson} ({priorId.Character}) and " +
                        $"lesson {lesson} ({k.Kanji}).");
                }
                else
                {
                    ids.Add(k.Id, (lesson, k.Kanji));
                }

                if (characters.TryGetValue(k.Kanji, out var priorChar))
                {
                    duplicates.Add($"Duplicate Kanji character {k.Kanji}: " +
                        $"lesson {priorChar.Lesson} (ID {priorChar.Id}) and " +
                        $"lesson {lesson} (ID {k.Id}).");
                }
                else
                {
                    characters.Add(k.Kanji, (k.Id, lesson));
                }

                CheckMeanings(k.Meanings, $"Kanji {k.Id}");
                CheckReadings(k.Readings, $"Kanji {k.Id}", kanji: true);
                result.Add(k);
            }
        }
        if (duplicates.Count > 0)
        {
            Console.Error.WriteLine($"Found {duplicates.Count} duplicate Kanji conflicts:");
            foreach (string duplicate in duplicates)
                Console.Error.WriteLine($"  - {duplicate}");
            throw new InvalidDataException(
                "Kanji files contain duplicate IDs/characters. " +
                "Review the listed lessons before importing.");
        }
        return result;
    }

    private static async Task<List<VocabularyEnvelope>> LoadVocabularyAsync(string path)
    {
        if (!File.Exists(path))
            throw new FileNotFoundException("Vocabulary JSON not found", path);

        string json = await File.ReadAllTextAsync(path);
        var entries = JsonSerializer.Deserialize<List<VocabularyEnvelope>>(json, JsonOptions)
            ?? throw new InvalidDataException("Vocabulary JSON is not an array.");
        var result = new List<VocabularyEnvelope>();
        var ids = new HashSet<int>();
        int kanaOnly = 0, hidden = 0;

        foreach (var v in entries)
        {
            if (v.Object == "kana_vocabulary")
            {
                kanaOnly++;
                continue;
            }
            if (v.Object != "vocabulary")
                throw new InvalidDataException($"Unexpected subject type: {v.Object}");
            if (v.Data == null)
                throw new InvalidDataException($"Missing data for vocabulary {v.Id}");
            if (v.Data.HiddenAt != null)
            {
                hidden++;
                continue;
            }

            if (v.Id <= 0 || !ids.Add(v.Id))
                throw new InvalidDataException($"Invalid/duplicate vocabulary ID: {v.Id}");
            if (v.Data.Level is < 1 or > 60 || string.IsNullOrWhiteSpace(v.Data.Characters))
                throw new InvalidDataException($"Invalid level/word for vocabulary {v.Id}");

            CheckMeanings(v.Data.Meanings, $"Vocabulary {v.Id}");
            CheckReadings(v.Data.Readings, $"Vocabulary {v.Id}", kanji: false);
            result.Add(v);
        }

        Console.WriteLine($"Skipped {kanaOnly} Kana-only subjects and {hidden} hidden vocabulary subjects.");
        return result;
    }

    private static void CheckMeanings(List<Meaning>? meanings, string subject)
    {
        if (meanings is not { Count: > 0 })
            throw new InvalidDataException($"{subject} has no meanings.");
        var seen = new HashSet<string>(StringComparer.Ordinal);
        foreach (var m in meanings)
        {
            if (string.IsNullOrWhiteSpace(m.Text))
                throw new InvalidDataException($"{subject} has an empty meaning.");
            if (!seen.Add(m.Text.Trim().ToLowerInvariant()))
                throw new InvalidDataException($"{subject} has a duplicate normalized meaning: {m.Text}");
        }
    }

    private static void CheckReadings(List<Reading>? readings, string subject, bool kanji)
    {
        if (readings is not { Count: > 0 })
            throw new InvalidDataException($"{subject} has no readings.");
        var seen = new HashSet<string>(StringComparer.Ordinal);
        foreach (var r in readings)
        {
            if (string.IsNullOrWhiteSpace(r.Text))
                throw new InvalidDataException($"{subject} has an empty reading.");
            if (kanji && r.Type is not ("onyomi" or "kunyomi" or "nanori"))
                throw new InvalidDataException($"{subject} has invalid reading type: {r.Type}");
            string key = kanji ? $"{r.Type}\u0000{r.Text}" : r.Text;
            if (!seen.Add(key))
                throw new InvalidDataException($"{subject} has duplicate reading: {r.Text}");
        }
    }

    private static async Task EnsureJapaneseTablesEmptyAsync(
        NpgsqlConnection connection, NpgsqlTransaction transaction)
    {
        const string sql = """
            SELECT (SELECT COUNT(*) FROM japaneselessons)
                 + (SELECT COUNT(*) FROM kanji)
                 + (SELECT COUNT(*) FROM japanesevocabulary)
            """;
        await using var command = new NpgsqlCommand(sql, connection, transaction);
        long count = (long)(await command.ExecuteScalarAsync()
            ?? throw new InvalidOperationException("Could not check database state."));
        if (count != 0)
            throw new InvalidOperationException(
                "Japanese data already exists. Import only into empty Japanese tables; " +
                "nothing was changed.");
    }

    private static async Task VerifyCountsAsync(
        NpgsqlConnection db, NpgsqlTransaction transaction,
        List<KanjiRow> kanjiRows, List<VocabularyRow> vocabularyRows)
    {
        // These names are constants written in code, not user-supplied SQL.
        var expected = new Dictionary<string, long>
        {
            ["japaneselessons"] = 60,
            ["kanjilessons"] = 60,
            ["vocabularylessons"] = 60,
            ["kanji"] = kanjiRows.Count,
            ["kanjimeanings"] = kanjiRows.Sum(k => k.Subject.Meanings.Count),
            ["kanjireadings"] = kanjiRows.Sum(k => k.Subject.Readings.Count),
            ["japanesevocabulary"] = vocabularyRows.Count,
            ["vocabularymeanings"] = vocabularyRows.Sum(v => v.Subject.Data!.Meanings.Count),
            ["vocabularyreadings"] = vocabularyRows.Sum(v => v.Subject.Data!.Readings.Count)
        };

        foreach (var (table, count) in expected)
        {
            await using var command = new NpgsqlCommand($"SELECT COUNT(*) FROM {table}", db, transaction);
            long actual = (long)(await command.ExecuteScalarAsync()
                ?? throw new InvalidOperationException($"Could not count {table}."));
            if (actual != count)
                throw new InvalidOperationException(
                    $"Verification failed for {table}: expected {count}, found {actual}.");
        }
        Console.WriteLine("All nine content table counts verified.");
    }

    private static async Task ImportLessonsAsync(
        NpgsqlConnection db, Dictionary<int, Guid> lessonIds)
    {
        await using (var writer = await db.BeginBinaryImportAsync(
            "COPY japaneselessons (lessonnumber, lessonid) FROM STDIN (FORMAT BINARY)"))
        {
            foreach (var (number, id) in lessonIds.OrderBy(x => x.Key))
            {
                await writer.StartRowAsync();
                await writer.WriteAsync(number, NpgsqlDbType.Integer);
                await writer.WriteAsync(id, NpgsqlDbType.Uuid);
            }
            await writer.CompleteAsync();
        }

        await using (var writer = await db.BeginBinaryImportAsync(
            "COPY kanjilessons (lessonid) FROM STDIN (FORMAT BINARY)"))
        {
            foreach (var id in lessonIds.Values)
            {
                await writer.StartRowAsync();
                await writer.WriteAsync(id, NpgsqlDbType.Uuid);
            }
            await writer.CompleteAsync();
        }

        await using (var writer = await db.BeginBinaryImportAsync(
            "COPY vocabularylessons (lessonid) FROM STDIN (FORMAT BINARY)"))
        {
            foreach (var id in lessonIds.Values)
            {
                await writer.StartRowAsync();
                await writer.WriteAsync(id, NpgsqlDbType.Uuid);
            }
            await writer.CompleteAsync();
        }
    }

    private static async Task ImportKanjiAsync(
        NpgsqlConnection db, Dictionary<int, Guid> lessons, List<KanjiRow> rows)
    {
        await using var writer = await db.BeginBinaryImportAsync(
            "COPY kanji (kanjiid, meaningid, readingid, lessonid, character) FROM STDIN (FORMAT BINARY)");
        foreach (var row in rows)
        {
            await writer.StartRowAsync();
            await writer.WriteAsync(row.Subject.Id, NpgsqlDbType.Integer);
            await writer.WriteAsync(row.MeaningId, NpgsqlDbType.Uuid);
            await writer.WriteAsync(row.ReadingId, NpgsqlDbType.Uuid);
            await writer.WriteAsync(lessons[row.Subject.LessonNumber], NpgsqlDbType.Uuid);
            await writer.WriteAsync(row.Subject.Kanji, NpgsqlDbType.Text);
        }
        await writer.CompleteAsync();
    }

    private static async Task ImportKanjiMeaningsAsync(NpgsqlConnection db, List<KanjiRow> rows)
    {
        await using var writer = await db.BeginBinaryImportAsync(
            "COPY kanjimeanings (meaningid, meaning, acceptedanswer) FROM STDIN (FORMAT BINARY)");
        foreach (var row in rows)
        foreach (var meaning in row.Subject.Meanings)
        {
            await writer.StartRowAsync();
            await writer.WriteAsync(row.MeaningId, NpgsqlDbType.Uuid);
            await writer.WriteAsync(meaning.Text, NpgsqlDbType.Text);
            await writer.WriteAsync(meaning.AcceptedAnswer, NpgsqlDbType.Boolean);
        }
        await writer.CompleteAsync();
    }

    private static async Task ImportKanjiReadingsAsync(NpgsqlConnection db, List<KanjiRow> rows)
    {
        await using var writer = await db.BeginBinaryImportAsync(
            "COPY kanjireadings (readingid, reading, readingtype, acceptedanswer) FROM STDIN (FORMAT BINARY)");
        foreach (var row in rows)
        foreach (var reading in row.Subject.Readings)
        {
            await writer.StartRowAsync();
            await writer.WriteAsync(row.ReadingId, NpgsqlDbType.Uuid);
            await writer.WriteAsync(reading.Text, NpgsqlDbType.Text);
            await writer.WriteAsync(reading.Type!, NpgsqlDbType.Text);
            await writer.WriteAsync(reading.AcceptedAnswer, NpgsqlDbType.Boolean);
        }
        await writer.CompleteAsync();
    }

    private static async Task ImportVocabularyAsync(
        NpgsqlConnection db, Dictionary<int, Guid> lessons, List<VocabularyRow> rows)
    {
        await using var writer = await db.BeginBinaryImportAsync(
            "COPY japanesevocabulary (vocabularyid, meaningid, readingid, lessonid, word) FROM STDIN (FORMAT BINARY)");
        foreach (var row in rows)
        {
            await writer.StartRowAsync();
            await writer.WriteAsync(row.Subject.Id, NpgsqlDbType.Integer);
            await writer.WriteAsync(row.MeaningId, NpgsqlDbType.Uuid);
            await writer.WriteAsync(row.ReadingId, NpgsqlDbType.Uuid);
            await writer.WriteAsync(lessons[row.Subject.Data!.Level], NpgsqlDbType.Uuid);
            await writer.WriteAsync(row.Subject.Data.Characters, NpgsqlDbType.Text);
        }
        await writer.CompleteAsync();
    }

    private static async Task ImportVocabularyMeaningsAsync(NpgsqlConnection db, List<VocabularyRow> rows)
    {
        await using var writer = await db.BeginBinaryImportAsync(
            "COPY vocabularymeanings (meaningid, meaning, acceptedanswer) FROM STDIN (FORMAT BINARY)");
        foreach (var row in rows)
        foreach (var meaning in row.Subject.Data!.Meanings)
        {
            await writer.StartRowAsync();
            await writer.WriteAsync(row.MeaningId, NpgsqlDbType.Uuid);
            await writer.WriteAsync(meaning.Text, NpgsqlDbType.Text);
            await writer.WriteAsync(meaning.AcceptedAnswer, NpgsqlDbType.Boolean);
        }
        await writer.CompleteAsync();
    }

    private static async Task ImportVocabularyReadingsAsync(NpgsqlConnection db, List<VocabularyRow> rows)
    {
        await using var writer = await db.BeginBinaryImportAsync(
            "COPY vocabularyreadings (readingid, reading, acceptedanswer) FROM STDIN (FORMAT BINARY)");
        foreach (var row in rows)
        foreach (var reading in row.Subject.Data!.Readings)
        {
            await writer.StartRowAsync();
            await writer.WriteAsync(row.ReadingId, NpgsqlDbType.Uuid);
            await writer.WriteAsync(reading.Text, NpgsqlDbType.Text);
            await writer.WriteAsync(reading.AcceptedAnswer, NpgsqlDbType.Boolean);
        }
        await writer.CompleteAsync();
    }
}

internal sealed record KanjiRow(KanjiSubject Subject, Guid MeaningId, Guid ReadingId);
internal sealed record VocabularyRow(VocabularyEnvelope Subject, Guid MeaningId, Guid ReadingId);

internal sealed class KanjiEnvelope
{
    [JsonPropertyName("KanjiJson")]
    public KanjiSubject? KanjiJson { get; set; }
}

internal sealed class KanjiSubject
{
    [JsonPropertyName("lessonNumber")]
    public int LessonNumber { get; set; }

    [JsonPropertyName("id")]
    public int Id { get; set; }

    [JsonPropertyName("kanji")]
    public string Kanji { get; set; } = "";

    [JsonPropertyName("meanings")]
    public List<Meaning> Meanings { get; set; } = [];

    [JsonPropertyName("readings")]
    public List<Reading> Readings { get; set; } = [];
}

internal sealed class VocabularyEnvelope
{
    [JsonPropertyName("id")]
    public int Id { get; set; }

    [JsonPropertyName("object")]
    public string Object { get; set; } = "";

    [JsonPropertyName("data")]
    public VocabularyData? Data { get; set; }
}

internal sealed class VocabularyData
{
    [JsonPropertyName("level")]
    public int Level { get; set; }

    [JsonPropertyName("characters")]
    public string Characters { get; set; } = "";

    [JsonPropertyName("hidden_at")]
    public string? HiddenAt { get; set; }

    [JsonPropertyName("meanings")]
    public List<Meaning> Meanings { get; set; } = [];

    [JsonPropertyName("readings")]
    public List<Reading> Readings { get; set; } = [];
}

internal sealed class Meaning
{
    [JsonPropertyName("meaning")]
    public string Text { get; set; } = "";

    [JsonPropertyName("accepted_answer")]
    public bool AcceptedAnswer { get; set; }
}

internal sealed class Reading
{
    [JsonPropertyName("reading")]
    public string Text { get; set; } = "";

    [JsonPropertyName("type")]
    public string? Type { get; set; }

    [JsonPropertyName("accepted_answer")]
    public bool AcceptedAnswer { get; set; }
}
