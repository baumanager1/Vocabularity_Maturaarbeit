# Vocabularity Japanese data importer

A **one-time**, standalone .NET 8 console program that imports your Kanji and filtered WaniKani vocabulary JSON files into your existing PostgreSQL tables. It is not part of the website or the ASP.NET Core API.

## Requirements

- .NET 8 SDK (or an SDK that can target net8.0)
- PostgreSQL accessible from the computer running this importer
- Your Japanese content tables created using the schema discussed (including `acceptedanswer` on the four meaning/reading tables)
- The 60 Kanji JSON files named exactly `Kanjis_Lesson1.json` through `Kanjis_Lesson60.json`, in one folder
- Your `wanikani_vocabulary.json` file; it may be in another folder

## Run on Windows PowerShell

In PowerShell, change directory to the folder containing `JapaneseDataImporter.csproj`.

First, **validate all JSONs without touching the database**:

```powershell
dotnet run -- "C:\Path\To\KanjiFolder" "C:\Path\To\wanikani_vocabulary.json" --validate-only
```

Next set a connection string in the **current PowerShell session only**:

```powershell
$env:VOCABULARITY_POSTGRES_CONNECTION = 'Host=192.168.1.114;Port=5432;Database=vocabularity;Username=developers;Password=YOUR_PASSWORD'
```

Adjust the host, database, username and password as appropriate. Do not commit credentials to Git.

Perform the import:

```powershell
dotnet run -- "C:\Path\To\KanjiFolder" "C:\Path\To\wanikani_vocabulary.json"
```

The importer will create 60 `japaneselessons`, 60 `kanjilessons`, 60 `vocabularylessons`, then Kanji and vocabulary with all of their *regular* meanings and readings.

It imports only vocabulary entries with `object == "vocabulary"` and `data.hidden_at == null`. It ignores Kana-only vocabulary, hidden vocabulary, `auxiliary_meanings`, `primary`, and other fields not represented in your schema. WaniKani original numeric IDs are preserved. The program never inserts anything into user progress tables.

## Safety

- All 60 Kanji files must exist. Every JSON is parsed and validated before connecting to PostgreSQL.
- Existing Japanese data are **not** overwritten or deleted. Importing into a database that already has Japanese lessons/Kanji/vocabulary fails.
- PostgreSQL `COPY BINARY` is used for speed; all inserts run inside one transaction.
- On any database error, the entire import is rolled back. There is no partial import.
- The program generates UUIDs for lesson references and for each subject's collection IDs (`meaningid`, `readingid`) so the parent/child relationships match your SQL schema.

## Check results

```sql
SELECT COUNT(*) FROM japaneselessons;       -- should be 60
SELECT COUNT(*) FROM kanjilessons;           -- should be 60
SELECT COUNT(*) FROM vocabularylessons;      -- should be 60
SELECT COUNT(*) FROM kanji;
SELECT COUNT(*) FROM kanjimeanings;
SELECT COUNT(*) FROM kanjireadings;
SELECT COUNT(*) FROM japanesevocabulary;
SELECT COUNT(*) FROM vocabularymeanings;
SELECT COUNT(*) FROM vocabularyreadings;
```

The Kanji file you uploaded here (`Kanjis_Lesson1.json`) has 36 entries; you need all 60 original files on your computer to run the full import. The ZIP contains only importer source code and documentation, not your JSON data.

## Duplicate Kanji validation

If the Kanji JSON files contain the same WaniKani ID or character in multiple lessons,
validation prints **all** duplicate conflicts with the lesson numbers where each record
occurs. Since the database has unique constraints on both `kanjiid` and `character`,
conflicting rows cannot both be imported. Review the original data and choose the
appropriate lesson; do not blindly delete a record or disable those constraints.

## Troubleshooting

- `relation "japaneselessons" does not exist`: run your `CREATE TABLE` scripts in the target database first.
- `column "acceptedanswer" does not exist`: ensure you are using your latest database schema.
- `permission denied`: check the database user's permissions.
- `Japanese data already exists`: use a fresh/empty Japanese content schema for a one-time import. Do not delete data you need.
- `duplicate key value violates unique constraint`: a unique constraint conflicts with imported data; the transaction is rolled back. Inspect the data/constraint before retrying.

The importer uses original WaniKani subject data. Review its terms and licensing before republishing content on a public website.
